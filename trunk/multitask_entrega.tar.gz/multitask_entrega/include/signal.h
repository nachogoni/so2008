#ifndef _signal_
#define _signal_

enum { SIGKILL = 9};

#endif
