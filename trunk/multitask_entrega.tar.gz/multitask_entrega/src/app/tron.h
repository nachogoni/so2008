#ifndef TRON_H_
#define TRON_H_

int init_tron(int ppid, int pid, char * parameters);

#endif /*TRON_H_*/
