#ifndef _top_
#define _top_

int topApp(int ppid, int pid, char * parameters);

#endif
