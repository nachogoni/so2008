#include "../../include/io.h"

#ifndef _presenta_
#define _presenta_

int init_presents(int ppid, int pid, char * parameters);

#endif

