#ifndef _duplicate_h_
#define _duplicate_h_

int duplicate(int ppid, int pid, char * parameters);

#endif