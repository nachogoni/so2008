#ifndef MALLOCCER_H_
#define MALLOCCER_H_

int malloccer(void);

#endif
