#include "excep.h"

int dividebyzero(void){
	int i;
	i /= 0;
	return 1;
}
