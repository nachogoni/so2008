#ifndef GAMES_H_
#define GAMES_H_

int game(int ppid, int pid, char * parameters);

int hangman(int ppid, int pid, char * parameters);

#endif /*GAMES_H_*/
