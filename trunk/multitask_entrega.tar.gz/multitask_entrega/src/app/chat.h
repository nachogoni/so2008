#ifndef CHAT_H_
#define CHAT_H_

int init_chat(int ppid, int pid, char * parameters);

#endif /*CHAT_H_*/
